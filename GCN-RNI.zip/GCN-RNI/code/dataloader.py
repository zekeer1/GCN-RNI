"""
Created on Mar 1, 2020
Pytorch Implementation of LightGCN in
Xiangnan He et al. LightGCN: Simplifying and Powering Graph Convolution Network for Recommendation

@author: Shuxian Bi (stanbi@mail.ustc.edu.cn),Jianbai Ye (gusye@mail.ustc.edu.cn)
Design Dataset here
Every dataset's index has to start at 0
"""
import os
from os.path import join
import sys
import torch
import numpy as np
import pandas as pd
from torch.utils.data import Dataset, DataLoader
from scipy.sparse import csr_matrix
import scipy.sparse as sp
import world
from world import cprint
from time import time

class BasicDataset(Dataset):
    def __init__(self):
        print("init dataset")
    
    @property
    def n_users(self):
        raise NotImplementedError
    
    @property
    def m_items(self):
        raise NotImplementedError
    
    @property
    def trainDataSize(self):
        raise NotImplementedError
    
    @property
    def testDict(self):
        raise NotImplementedError
    
    @property
    def allPos(self):
        raise NotImplementedError
    
    def getUserItemFeedback(self, users, items):
        raise NotImplementedError
    
    def getUserPosItems(self, users):
        raise NotImplementedError
    
    def getUserNegItems(self, users):
        """
        not necessary for large dataset
        it's stupid to return all neg items in super large dataset
        """
        raise NotImplementedError
    
    def getSparseGraph(self):
        """
        build a graph in torch.sparse.IntTensor.
        Details in NGCF's matrix form
        A = 
            |I,   R|
            |R^T, I|
        """
        raise NotImplementedError


class LastFM(BasicDataset):
    """
    Dataset type for pytorch \n
    Incldue graph information
    LastFM dataset
    """

    def __init__(self, path="../.../lastfm"):
        # train or test
        cprint("loading [last fm]")
        self.mode_dict = {'train': 0, "test": 1}
        self.mode = self.mode_dict['train']
        trainData = pd.read_table(join(path, 'data1'), header=None)
        testData = pd.read_table(join(path, 'test1'), header=None)
        trainData -= 1
        testData -= 1
        #集合代表了与某用户相似的用户的集合
        #self.trustNet = trustNet
        self.trainData = trainData
        self.testData = testData
        self.trainUser = np.array(trainData[:][0])
        self.trainUniqueUsers = np.unique(self.trainUser)
        self.trainItem = np.array(trainData[:][1])
        self.xunlian= np.array(trainData[:][2])
        # self.trainDataSize = len(self.trainUser
        self.testUser = np.array(testData[:][0])
        self.testUniqueUsers = np.unique(self.testUser)
        self.testItem = np.array(testData[:][1])
        self.Graph = None
        print(f"LastFm Sparsity : {(len(self.trainUser) + len(self.testUser)) / self.n_users / self.m_items}")
        # (users,users)用户之间的信任网络
        # (users,items), bipartite graph用户和项目之间的信任网络
        train_file = pd.read_csv('D:\...lastfm\data1', delimiter='\t', header=None)
        N = 2945
        M=17384
        data_matrix = np.zeros((N,M))
        for line in train_file.itertuples():
               data_matrix[line[1] - 1, line[2] - 1] = line[3]
        #data_matrix表示次数矩阵

        train_file = pd.read_csv('D:\...lastfm\data1', delimiter='\t', header=None)
        lianjie_matrix= np.zeros((N,M))
        for line in train_file.itertuples():
            lianjie_matrix[line[1] - 1, line[2] - 1] = 1
       #lianjie_matri是连接矩阵

        index =6
        for i in range(N):
            for j in range(M):
                if (data_matrix[i][j] < index ):
                    lianjie_matrix[i][j] = 0
                    #此时的连接矩阵表示的是经过筛选之后的连接矩阵
        self.after_matrixNet = csr_matrix(lianjie_matrix)
        self._allPos = self.getUserPosItems(list(range(self.n_users)))
        self._allNeg = []
        MidItems = []
        for i in range(self.n_users):
            a = []
            for j in range(self.m_items):
                if (0 < data_matrix[i][j] <index):
                    a.append(j)
            MidItems.append(a)
        self._allMid = MidItems
        #lianjie_matrix2矩阵表示我们构建的相似信息矩阵
        #user_set2和 item_set2表示的是0相似的用户和项目信息
        allItems = set(range(self.m_items))
        for i in range(self.n_users):
            pos = set(self._allPos[i])
            mid = set(self._allMid[i])
            neg = allItems - pos - mid
            self._allNeg.append(np.array(list(neg)))
        self.__testDict = self.__build_test()

    @property
    def n_users(self):
        return 2945
    
    @property
    def m_items(self):
        return 17384
    
    @property
    def trainDataSize(self):
        return len(self.trainUser)
    
    @property
    def testDict(self):
        return self.__testDict

    @property
    def allPos(self):
        return self._allPos

    @property
    def allMid(self):
        return self._allMid

    @property
    def allNeg(self):
        return self._allNeg

    def getSparseGraph(self):
        if self.Graph is None:
            user_dim1 = torch.LongTensor(self.trainUser1)
            item_dim1 = torch.LongTensor(self.trainItem1)
            first_sub1 = torch.stack([user_dim1, item_dim1 + self.n_users])
            second_sub1 = torch.stack([item_dim1+self.n_users, user_dim1])
            index1 = torch.cat([first_sub1, second_sub1], dim=1)
            data1 = torch.ones(index1.size(-1)).int()
            self.Graph1 = torch.sparse.IntTensor(index1, data1, torch.Size([self.n_users+self.m_items, self.n_users+self.m_items]))
            dense1 = self.Graph1.to_dense()

            dense = dense1
            D1 = torch.sum(dense1, dim=1).float()
            D = D1
            D[D == 0.] = 1.
            D_sqrt = torch.sqrt(D).unsqueeze(dim=0)
            dense = dense / D_sqrt
            dense = dense / D_sqrt.t()
            index = dense.nonzero()
            data = dense[dense >= 1e-9]
            assert len(index) == len(data)
            self.Graph = torch.sparse.FloatTensor(index.t(), data, torch.Size([self.n_users+self.m_items, self.n_users+self.m_items]))
            self.Graph = self.Graph.coalesce().to(world.device)
        return self.Graph

    def __build_test(self):
        """
        return:
            dict: {user: [items]}
        """
        test_data = {}
        for i, item in enumerate(self.n):
            user = self.m[i]
            if test_data.get(user):
                test_data[user].append(item)
            else:
                test_data[user] = [item]
        return test_data


    def getUserPosItems(self,users):
        posItems = []
        for user in users:
            posItems.append(self.after_matrixNet[user].nonzero()[1])
        return posItems
