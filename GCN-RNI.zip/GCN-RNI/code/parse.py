'''
Created on Mar 1, 2020
Pytorch Implementation of LightGCN in
Xiangnan He et al. LightGCN: Simplifying and Powering Graph Convolution Network for Recommendation

@author: Jianbai Ye (gusye@mail.ustc.edu.cn)
'''
import argparse


def parse_args():
    parser = argparse.ArgumentParser(description="Go GCN-RNI")
    parser.add_argument('--bpr_batch', type=int,default=2048,)

    parser.add_argument('--recdim', type=int,default=64,)

    parser.add_argument('--layer', type=int,default=3,)

    parser.add_argument('--lr', type=float,default=0.001,)

    parser.add_argument('--decay', type=float,default=6e-4,)

    parser.add_argument('--dropout', type=int,default=0,
                        help="using the dropout or not")

    parser.add_argument('--keepprob', type=float,default=0.6,)

    parser.add_argument('--testbatch', type=int,default=100,)

    parser.add_argument('--dataset', type=str,default='lastfm',)

    parser.add_argument('--topks', nargs='?',default="[5,10,20]",
                        help="@k test list")
    parser.add_argument('--tensorboard', type=int,default=1,
                        help="enable tensorboard")
    parser.add_argument('--load', type=int,default=0)
    parser.add_argument('--epochs', type=int,default=1000)
    parser.add_argument('--seed', type=int, default=2020, help='random seed')
    #随机种子，如果随机种子数不变，那么生成的随机数也不会变
    parser.add_argument('--model', type=str, default='GCN-RNI', help='rec-model, support [GCN-RNI]')
    return parser.parse_args()
