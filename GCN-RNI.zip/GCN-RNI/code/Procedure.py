'''
Created on Mar 1, 2020
Pytorch Implementation of LightGCN in
Xiangnan He et al. LightGCN: Simplifying and Powering Graph Convolution Network for Recommendation
@author: Jianbai Ye (gusye@mail.ustc.edu.cn)

Design training and test process
'''
import world
import numpy as np
import torch
import utils
import dataloader
from pprint import pprint
from time import time
from tqdm import tqdm
import model
import multiprocessing
#并行处理模块
from sklearn.metrics import roc_auc_score
def BPRRNI_train_original(dataset, recommend_model, loss_class, epoch,  w=None):
    Recmodel = recommend_model
    Recmodel.train()
    bpr: utils.BPRLoss = loss_class
    allusers = list(range(dataset.n_users))
    S, S1= utils.UniformSample_original(allusers, dataset)
    users1 = torch.Tensor(S1[:, 0]).long()
    posItems1 = torch.Tensor(S1[:, 1]).long()
    negItems1 = torch.Tensor(S1[:, 2]).long()
    midItems1 = torch.Tensor(S1[:, 3]).long()
    users1 = users1.to(world.device)
    posItems1 = posItems1.to(world.device)
    negItems1 = negItems1.to(world.device)
    midItems1 = midItems1.to(world.device)
    users1, posItems1, midItems1, midItems1 = utils.shuffle(users1, posItems1, negItems1, midItems1)
    aver_loss1 = 0.
    for  (batch_i,
         (batch_users,
          batch_pos,
          batch_neg,
          batch_mid)) in enumerate(utils.minibatch(users1,
                                                   posItems1,
                                                   negItems1,
                                                   midItems1,
                                                   batch_size=world.config['bpr_batch_size'])):
        cri1 = bpr.stageOne1(batch_users, batch_pos, batch_neg, batch_mid)
        aver_loss1 += cri1
    total_batch1 = len(users1) // world.config['bpr_batch_size'] + 1
    users = torch.Tensor(S[:, 0]).long()
    posItems = torch.Tensor(S[:, 1]).long()
    negItems = torch.Tensor(S[:, 2]).long()
    users = users.to(world.device)
    posItems = posItems.to(world.device)
    negItems = negItems.to(world.device)
    users, posItems, negItems  = utils.shuffle(users, posItems, negItems)
    aver_loss = 0.
    for  (batch_i,
         (batch_users,
          batch_pos,
          batch_neg,)) in enumerate(utils.minibatch(users,
                                                    posItems,
                                                    negItems,
                                                    batch_size=world.config['bpr_batch_size'])):
        cri = bpr.stageOne(batch_users, batch_pos, batch_neg)
        aver_loss += cri
        total_batch = len(users) // world.config['bpr_batch_size'] + 1
        if world.tensorboard:
            w.add_scalar(f'BPRLoss/BPR', cri, epoch * int(len(users) / world.config['bpr_batch_size']) + batch_i)
    aver_loss =  aver_loss + aver_loss1
    total_batch = total_batch + total_batch1
    aver_loss = aver_loss / total_batch
    return f"[BPR[aver loss{aver_loss:.3e}]"
    
def test_one_batch(X):
    sorted_items = X[0].numpy()
    groundTrue = X[1]
    r = utils.getLabel(groundTrue, sorted_items)
    pre, recall, ndcg = [], [], []
    for k in world.topks:
        ret = utils.RecallPrecision_ATk(groundTrue, r, k)
        pre.append(ret['precision'])
        recall.append(ret['recall'])
        ndcg.append(utils.NDCGatK_r(groundTrue,r,k))
    return {'recall':np.array(recall), 
            'precision':np.array(pre), 
            'ndcg':np.array(ndcg)}
        
            
def Test(dataset, Recmodel, epoch, w=None, multicore=0):
    u_batch_size = world.config['test_u_batch_size']
    dataset: utils.BasicDataset
    testDict: dict = dataset.testDict
    Recmodel = Recmodel.eval()
    max_K = max(world.topks)
    with torch.no_grad():
        users = list(testDict.keys())
        try:
            assert u_batch_size <= len(users) / 10
        except AssertionError:
            print(f"test_u_batch_size is too big for this dataset, try a small one {len(users) // 10}")
        users_list = []
        rating_list = []
        groundTrue_list = []
        auc_record = []
        total_batch = len(users) // u_batch_size + 1
        for batch_users in utils.minibatch(users, batch_size=u_batch_size):
            allPos = dataset.getUserPosItems(batch_users)
            groundTrue = [testDict[u] for u in batch_users]
            batch_users_gpu = torch.Tensor(batch_users).long()
            batch_users_gpu = batch_users_gpu.to(world.device)
            rating = Recmodel.getUsersRating(batch_users_gpu)
            rating = rating.cpu()
            exclude_index = []
            exclude_items = []
            for range_i, items in enumerate(allPos):
                exclude_index.extend([range_i] * len(items))
                exclude_items.extend(items)
            rating[exclude_index, exclude_items] = -(1<<10)
            _, rating_K = torch.topk(rating, k=max_K)
            rating = rating.cpu().numpy()
            aucs = [
                    utils.AUC(rating[i],
                              dataset,
                              test_data) for i, test_data in enumerate(groundTrue)
                ]
            auc_record.extend(aucs)
            del rating
            users_list.append(batch_users)
            rating_list.append(rating_K.cpu())
            groundTrue_list.append(groundTrue)
        assert total_batch == len(users_list)
        X = zip(rating_list, groundTrue_list)
        for result in pre_results:
            results['recall'] += result['recall']
            results['precision'] += result['precision']
            results['ndcg'] += result['ndcg']
        results['recall'] /= float(len(users))
        results['precision'] /= float(len(users))
        results['ndcg'] /= float(len(users))
        results['auc'] = np.mean(auc_record)
        print(results)
        return results